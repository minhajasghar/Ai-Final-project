from models.patient import Patient
from models.diagnosis import Diagnosis
from utils.symptom_analyzer import SymptomAnalyzer
from utils.logger import Logger

class DiagnosticService:
    def __init__(self):
        self.logger = Logger()
        self.symptom_analyzer = SymptomAnalyzer()
        
    def diagnose(self, patient: Patient) -> Diagnosis:
        self.logger.info(f"Starting diagnosis for patient {patient.id}")
        
        # Analyze symptoms
        conditions = self.symptom_analyzer.analyze(patient.symptoms)
        
        # Generate recommendations based on conditions
        recommendations = self._generate_recommendations(conditions)
        
        # Calculate confidence score
        confidence = self._calculate_confidence(conditions, patient.symptoms)
        
        diagnosis = Diagnosis(
            patient_id=patient.id,
            possible_conditions=conditions,
            confidence=confidence,
            recommendations=recommendations
        )
        
        self.logger.info(f"Diagnosis completed for patient {patient.id}")
        return diagnosis
    
    def _generate_recommendations(self, conditions: list) -> list:
        recommendations = []
        if "fever" in str(conditions).lower():
            recommendations.append("Rest and stay hydrated")
            recommendations.append("Monitor temperature regularly")
        if "cough" in str(conditions).lower():
            recommendations.append("Stay in a well-ventilated room")
            recommendations.append("Use steam inhalation")
        recommendations.append("Consult a healthcare professional for detailed evaluation")
        return recommendations
    
    def _calculate_confidence(self, conditions: list, symptoms: list) -> float:
        # Simple confidence calculation (to be enhanced with ML models)
        base_confidence = 70.0
        symptom_weight = len(symptoms) * 5
        return min(base_confidence + symptom_weight, 95.0)