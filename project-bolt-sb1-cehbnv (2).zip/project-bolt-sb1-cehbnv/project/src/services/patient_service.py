from models.patient import Patient
from utils.logger import Logger

class PatientService:
    def __init__(self):
        self.patients = {}
        self.logger = Logger()
        
    def register_patient(self, patient: Patient) -> bool:
        if patient.id in self.patients:
            self.logger.warning(f"Patient {patient.id} already exists")
            return False
            
        self.patients[patient.id] = patient
        self.logger.info(f"Patient {patient.id} registered successfully")
        return True
        
    def get_patient(self, patient_id: str) -> Patient:
        return self.patients.get(patient_id)
        
    def update_patient(self, patient: Patient) -> bool:
        if patient.id not in self.patients:
            self.logger.warning(f"Patient {patient.id} not found")
            return False
            
        self.patients[patient.id] = patient
        self.logger.info(f"Patient {patient.id} updated successfully")
        return True