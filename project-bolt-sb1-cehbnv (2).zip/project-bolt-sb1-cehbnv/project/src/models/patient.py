from dataclasses import dataclass
from typing import List

@dataclass
class Patient:
    id: str
    name: str
    age: int
    gender: str
    symptoms: List[str]
    medical_history: List[str] = None
    
    def __post_init__(self):
        if self.medical_history is None:
            self.medical_history = []
            
    def add_symptom(self, symptom: str):
        if symptom not in self.symptoms:
            self.symptoms.append(symptom)
            
    def add_medical_history(self, condition: str):
        if condition not in self.medical_history:
            self.medical_history.append(condition)