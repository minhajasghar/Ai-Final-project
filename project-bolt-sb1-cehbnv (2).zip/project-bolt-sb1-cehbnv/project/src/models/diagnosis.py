from dataclasses import dataclass
from typing import List

@dataclass
class Diagnosis:
    patient_id: str
    possible_conditions: List[str]
    confidence: float
    recommendations: List[str]
    timestamp: str = None
    
    def __post_init__(self):
        from datetime import datetime
        if self.timestamp is None:
            self.timestamp = datetime.now().isoformat()
            
    def add_condition(self, condition: str):
        if condition not in self.possible_conditions:
            self.possible_conditions.append(condition)
            
    def update_confidence(self, new_confidence: float):
        self.confidence = max(0.0, min(100.0, new_confidence))