from models.patient import Patient
from models.diagnosis import Diagnosis
from services.diagnostic_service import DiagnosticService
from services.patient_service import PatientService
from utils.data_validator import DataValidator
from utils.logger import Logger

def main():
    logger = Logger()
    logger.info("Starting MediAI Healthcare Diagnostic System")

    # Initialize services
    patient_service = PatientService()
    diagnostic_service = DiagnosticService()
    
    try:
        # Take user input
        print("Welcome to MediAI Healthcare Diagnostic System!")
        patient_id = input("Enter Patient ID: ").strip()
        name = input("Enter Patient Name: ").strip()
        age = int(input("Enter Patient Age: ").strip())
        gender = input("Enter Patient Gender (M/F): ").strip().upper()
        symptoms = input("Enter symptoms separated by commas: ").strip().split(',')

        # Create Patient object
        patient = Patient(
            id=patient_id,
            name=name,
            age=age,
            gender=gender,
            symptoms=[symptom.strip() for symptom in symptoms]
        )
        
        # Validate patient data
        if DataValidator.validate_patient(patient):
            # Register patient
            patient_service.register_patient(patient)
            
            # Perform diagnosis
            diagnosis = diagnostic_service.diagnose(patient)
            
            # Display results
            print("\nDiagnostic Results:")
            print(f"Patient: {patient.name}")
            print(f"Symptoms: {', '.join(patient.symptoms)}")
            print(f"Possible conditions: {', '.join(diagnosis.possible_conditions)}")
            print(f"Confidence: {diagnosis.confidence}%")
            print(f"Recommendations: {diagnosis.recommendations}")
        else:
            print("Invalid patient data. Please try again.")
            
    except ValueError as ve:
        logger.error(f"Invalid input: {str(ve)}")
        print("Please enter the correct data format.")
    except Exception as e:
        logger.error(f"An error occurred: {str(e)}")
        print("An unexpected error occurred. Please try again later.")

if __name__ == "__main__":
    main()
