from typing import List
import json
from utils.logger import Logger

class SymptomAnalyzer:
    def __init__(self):
        self.logger = Logger()
        self.symptom_map = {
            "fever": ["Common Cold", "Flu", "COVID-19"],
            "cough": ["Bronchitis", "Common Cold", "COVID-19"],
            "fatigue": ["Anemia", "Depression", "Flu"],
            "headache": ["Migraine", "Tension Headache", "Sinusitis"],
            "nausea": ["Food Poisoning", "Migraine", "Gastritis"]
        }
        
    def analyze(self, symptoms: List[str]) -> List[str]:
        self.logger.info(f"Analyzing symptoms: {symptoms}")
        possible_conditions = set()
        
        for symptom in symptoms:
            symptom = symptom.lower()
            if symptom in self.symptom_map:
                possible_conditions.update(self.symptom_map[symptom])
        
        # Sort conditions by frequency of occurrence
        condition_frequency = {}
        for condition in possible_conditions:
            count = sum(1 for symptom in symptoms if condition in self.symptom_map.get(symptom.lower(), []))
            condition_frequency[condition] = count
            
        sorted_conditions = sorted(condition_frequency.items(), key=lambda x: x[1], reverse=True)
        return [condition for condition, _ in sorted_conditions[:3]]