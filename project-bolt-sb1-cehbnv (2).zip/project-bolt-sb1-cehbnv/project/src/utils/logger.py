from datetime import datetime

class Logger:
    def __init__(self):
        self.log_file = "mediai.log"
        
    def _log(self, level: str, message: str):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_message = f"[{timestamp}] {level}: {message}"
        print(log_message)
        
        with open(self.log_file, "a") as f:
            f.write(log_message + "\n")
    
    def info(self, message: str):
        self._log("INFO", message)
        
    def warning(self, message: str):
        self._log("WARNING", message)
        
    def error(self, message: str):
        self._log("ERROR", message)
        
    def debug(self, message: str):
        self._log("DEBUG", message)