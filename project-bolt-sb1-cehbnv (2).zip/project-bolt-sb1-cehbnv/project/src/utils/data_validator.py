from models.patient import Patient
from utils.logger import Logger

class DataValidator:
    @staticmethod
    def validate_patient(patient: Patient) -> bool:
        logger = Logger()
        
        try:
            if not patient.id or not isinstance(patient.id, str):
                logger.error("Invalid patient ID")
                return False
                
            if not patient.name or not isinstance(patient.name, str):
                logger.error("Invalid patient name")
                return False
                
            if not isinstance(patient.age, int) or patient.age < 0 or patient.age > 150:
                logger.error("Invalid patient age")
                return False
                
            if not patient.gender or patient.gender not in ['M', 'F', 'O']:
                logger.error("Invalid patient gender")
                return False
                
            if not patient.symptoms or not isinstance(patient.symptoms, list):
                logger.error("Invalid symptoms list")
                return False
                
            return True
            
        except Exception as e:
            logger.error(f"Validation error: {str(e)}")
            return False